
export interface UserData {
  id?: number,
  rank?: string,
  name: string,
  netPoints: number;
}
