import { Injectable } from '@angular/core';
import { UserData } from './app.interfaces';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {
  private userData$ = new BehaviorSubject<UserData[]>([]);

  constructor() { }

  public get UserData$(): Observable<UserData[]> {
    return this.userData$.asObservable();
  }

  public addUser(data: UserData): void {
    const existingData = this.userData$.value;
    const userId = existingData?.length ? + existingData.length + 1 : 1;
    const userData = [
      ...existingData,
      {
        ...data,
        id: userId,
        rank: userId
      }
    ];
    let sameNetpointsExist = false;
    const modifiedUserData: UserData[] = existingData.map((user: UserData) => {
      if (user.netPoints !== data.netPoints) {
        return user
      }
      sameNetpointsExist = true;
      return { ...user, rank: `T${user.id}` }
    });

    const newUserData = [
      ...modifiedUserData,
      {
        ...data,
        id: userId,
        rank: sameNetpointsExist ? `T${userId}` : userId.toString()
      }
    ];

    this.userData$.next(this.sortUserData(newUserData));
  }

  public modifyUser(id: number, name: string, netPoints: number): void {
    const userData = this.userData$.value;
    const modifiedUserdata = userData.map((user: UserData) => {
      if (user.id === id) {
        const data = { ...user, name, netPoints }
        return { ...user, name, netPoints }
      } else {
        return user;
      }
    });

    this.userData$.next(this.sortUserData(modifiedUserdata));
  }

  public deleteUser(id: number): void {
    const userData = this.userData$.value;
    const currentUser = userData.find((user) => user.id === id);
    const sameNetpointUser = userData.filter(user => user.netPoints === currentUser.netPoints);
    let modifiedData;
    if (sameNetpointUser?.length === 2) {
      modifiedData = userData
        .filter(user => user.id !== id)
        .map((user: UserData) => {
          if (user.id === sameNetpointUser[0].id) {
            return { ...user, rank: user.id };
          } else {
            return user;
          }
        });
    } else {
      modifiedData = userData.filter(user => !!user?.id && user?.id !== id);
    }

    this.userData$.next(this.sortUserData(modifiedData));
  }

  private sortUserData(userData: UserData[]): UserData[] {
    return userData.sort((a, b) => (a.netPoints - b.netPoints))
  }
}
